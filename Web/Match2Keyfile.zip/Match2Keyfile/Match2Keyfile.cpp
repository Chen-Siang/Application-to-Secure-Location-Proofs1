#include <iostream>
#include <cstdlib>						// C standard library
#include <cstdio>						// C I/O (for sscanf)
#include <cstring>						// string manipulation
#include <fstream>						// file I/O
#include <math.h>
#include <vector>
#include <string>

using namespace std;

struct keypt_t {
    float x, y;
    float scale;
    float orient;
    int des[128];
};


istream* dataIn = NULL;			// input for data points
istream* matchdataIn = NULL;			// input for data points
int dkeynum = 0;
int	ddim =  0;			// dimension
int **matchIdx;
int *keynum;
int *matchkeynum;

vector< vector<struct keypt_t> > keypts;


void getkeyfile(const char *filePath){
    static ifstream dataStream;					// data file stream
    //static ifstream queryStream;				// query file stream

    //cout <<"type:\t"<<keyfilePath<<"\n";
    //if(!strcmp(type, "data_key")){
    if(dataStream.is_open())
        dataStream.close();
    dataStream.open(filePath, ios::in);// open data file
    //file_out = argv[i];
    if (!dataStream) {
        cerr << "Cannot open data file\n";
        exit(1);
    }
    dataIn = &dataStream;				// make this the data stream

    if (dataIn == NULL) {
        cerr << "read key file error\n";
        exit(1);
    }
}


void getmatchfile(const char *filePath){
    static ifstream datamatchStream;					// data file stream

    if(datamatchStream.is_open())
        datamatchStream.close();
    datamatchStream.open(filePath, ios::in);// open data file

    if (!datamatchStream) {
        cerr << "Cannot open data file\n";
        exit(1);
    }
    matchdataIn = &datamatchStream;				// make this the data stream

    if (matchdataIn == NULL) {
        cerr << "read match file error! \n";
        exit(1);
    }
}

bool readKeyNum()
{
    if(!(*dataIn >> dkeynum)) return false;
    if(!(*dataIn >> ddim)) return false;
    //cout << "(data_keynum: " << dkeynum<<",dim: "<<ddim<<")\n ";
    return true;
}

bool readPt(std::vector<struct keypt_t>& keyPt, int nPts)			// read point (false on EOF)
{
	struct keypt_t key;
	float x,y,scale,orient;

	if(!(*dataIn >> x)) return false;
	if(!(*dataIn >> y)) return false;
	if(!(*dataIn >> scale)) return false;
	if(!(*dataIn >> orient)) return false;
	//cout << x << y << scale << orient << endl;
	key.x = x;
	key.y = y;
	key.scale = scale;
	key.orient = orient;
	//cout << key.x << key.y << key.scale << key.orient << endl;

	for (int i = 0; i < 128; i++) {
		if(!(*dataIn >> key.des[i])) return false;
	}
	keyPt.push_back(key);

	return true;
}

int ReadFileList(char* list_in, std::vector<std::string>& key_files) {
    FILE* fp;

    if ((fp = fopen(list_in, "r")) == NULL) {
        printf("Error opening file %s for reading.\n", list_in);
        return 1;
    }

    char buf[512], *start;
    while (fgets(buf, 512, fp)) {
        // Remove trailing new-line
        if (buf[strlen(buf) - 1] == '\n') buf[strlen(buf) - 1] = '\0';

        // Find first non-space character
        start = buf;
        while(isspace(*start)) start++;

        // Skip empty lines
        if (strlen(start) == 0) continue;

        // Append file-name to key_files
        key_files.push_back(std::string(buf));
    }

    // Check we found input files
    if (key_files.size() == 0) {
        printf("No input files found in %s.\n", list_in);
        return 1;
    }

    return 0;
}

bool readMatchIdx(istream &in)  // read point (false on EOF)
{
	//matchdataIn
	//matchIdx
	int i, j, n, idx1, idx2;
	if(!(in >> i)) return false;
	if(!(in >> j)) return false;
	if(!(in >> n)) return false;
	//cout << i << "　"　<< j << " " << n << endl;
	for (int k = 0; k < n; k++) {
		if(!(in >> idx1)) return false;
		if(!(in >> idx2)) return false;
		if (matchIdx[i][idx1] == 0)
		{
			matchIdx[i][idx1] = 1;
			matchkeynum[i] = matchkeynum[i]+1;
		}
		if (matchIdx[j][idx2] == 0)
		{
			matchIdx[j][idx2] = 1;
			matchkeynum[j] = matchkeynum[j]+1;
		}
	}
	return true;
}

//writeKey2(outfile.c_str(), i, dkeynum, keypt);
bool writeKey2(const char *file_out, int imageIdx, int keynum, std::vector<struct keypt_t>& key_pt){
    FILE *f1;
    if ((f1 = fopen(file_out, "w")) == NULL) {
        printf("Could not open %s for writing.\n", file_out);
        return EXIT_FAILURE;
    }
    fprintf(f1,"%d %d\n", matchkeynum[imageIdx], 128);
    for (int i = 0; i < keynum; i++)
    {
        if (matchIdx[imageIdx][i] == 1)
        {
            //cout << key_pt[i].x << " " << key_pt[i].y << " " << key_pt[i].scale << " " << key_pt[i].orient << endl;
            fprintf(f1,"%.3lf %.3lf %.3lf %.3lf\n", key_pt[i].x, key_pt[i].y, key_pt[i].scale, key_pt[i].orient);

            for (int j = 0; j < 128; j++)
            {
                //cout j+1
                if ((j+1) % 20 == 0){
                    fprintf(f1,"%d\n", key_pt[i].des[j]);
                }
                else if ((j+1) % 128 == 0){
                    fprintf(f1,"%d\n", key_pt[i].des[j]);
                }
                else{
                    fprintf(f1,"%d ", key_pt[i].des[j]);
                }
            }
        }
    }
    fclose(f1);
    return true;

}
//writeKey(key_files[i], i, keynum[i], keypt, from, to);
bool writeKey(const char *file_out, int imageIdx, int keynum, std::vector<struct keypt_t>& key_pt, int from ,int to)  // read point (false on EOF)
{
	//matchdataIn
	//matchIdx
	FILE *f;
    if ((f = fopen(file_out, "w")) == NULL) {
        printf("Could not open %s for writing.\n", file_out);
        return EXIT_FAILURE;
    }
	//cout << file_out << endl;
    //cout << matchkeynum[imageIdx] << " 128" << endl;
    fprintf(f,"%d %d\n", matchkeynum[imageIdx], 128);

    for (int i = 0; i < keynum; i++)
    {
    	if (matchIdx[imageIdx][i] == 1)
    	{
	    	//cout << key_pt[from+i].x << " " << key_pt[from+i].y << " " << key_pt[from+i].scale << " " << key_pt[from+i].orient << endl;
	    	fprintf(f,"%.3lf %.3lf %.3lf %.3lf\n", key_pt[from+i].x, key_pt[from+i].y, key_pt[from+i].scale, key_pt[from+i].orient);

            for (int j = 0; j < 128; j++)
            {
            	//cout j+1
            	if ((j+1) % 20 == 0){
            		fprintf(f,"%d\n", key_pt[from+i].des[j]);
            	}
            	else if ((j+1) % 128 == 0){
            		fprintf(f,"%d\n", key_pt[from+i].des[j]);
            	}
            	else{
            		fprintf(f,"%d ", key_pt[from+i].des[j]);
            	}
            }
	    }
    }
    fclose(f);
	return true;
}


int main(int argc, char **argv)
{
    char *list_in;
    char *matches_list_in;
    char *file_out;

    if (argc !=3  && argc != 4) {
        printf("Usage: %s <list.txt> <matches.init.txt> <list_matches_keys.txt> \n", argv[0]);
        return EXIT_FAILURE;
    }

    list_in = argv[1];
    matches_list_in = argv[2];

    file_out = argv[3];

    FILE *f;
	if ((f = fopen(file_out, "w")) == NULL) {
	    printf("Could not open %s for writing.\n", file_out);
	    return EXIT_FAILURE;
	}

    //int window_radius = -1;
    int keyfiles_num;
    int matchIdxNum = 0;

    int nPts = 0;

    vector<struct keypt_t> keypt;
    vector<struct keypt_t> zero; //zero(0);
    
    //讀取key list file
    vector<string> key_files;
    if (ReadFileList(list_in, key_files) != 0) return EXIT_FAILURE;



    //cout << key_files.size() << endl;
    keyfiles_num = key_files.size();
    //keynum = new int[key_files.size()];
    matchkeynum = new int[key_files.size()];
    matchIdx = new int*[key_files.size()];


    //讀取match.inti.txt
    cout << "[ - Read match keys - ]\n";
//cout << matches_list_in << "_0\n";
    getmatchfile(matches_list_in);
//cout << matches_list_in << "_1\n";

    
    int dkeysize = 30000;
    for (int i=0; i < key_files.size(); i++){
	matchkeynum[i] = 0;
	matchIdx[i] = new int[dkeysize];
        for (int j=0; j < dkeysize; j++){
	    matchIdx[i][j] = 0;	
	}
    }
    matchIdxNum = 0;
    while (1) {
	//cout << matchIdxNum << "\n";
        if (readMatchIdx(*matchdataIn) == false){
            break;
        }
        matchIdxNum++;
    }
    cout << "[ - Read match keys done - ]\n";


    string outfile;
    //讀取key file
    cout << "[ - Read keys - ]\n";
    for(int i = 0; i < key_files.size(); i++)
    {
	//cout << "Read Key : " << i << "  " << key_files[i] << "\n";
    	//cout << key_files[i] << endl;
    	getkeyfile(key_files[i].c_str());
    	readKeyNum();
    	//cout << "dkeynum  " << dkeynum << endl;
    	//keynum[i] = dkeynum;
    	

    	nPts = 0;
	keypt.clear();
	keypt.swap(zero);
	    while (nPts < dkeynum && readPt(keypt, nPts)) {
	        nPts++;
	    }
        //cout << "[ - Write match keys - ]\n";
        outfile = key_files[i] + "matches.key";
        writeKey2(outfile.c_str(), i, dkeynum, keypt);
        fprintf(f,"%s\n", outfile.c_str());
	    //keypts[i].push_back(keypt);
	    //keypt.clear();
	cout << "Write match keys : " << i+1 << " / " << key_files.size() << "  " << outfile << "\n";
	}

	

	//寫入 key 檔
    /*
	cout << "[ - Write match keys - ]\n";
	int from = 0;
	int to = 0;
	string outfile;
	for (int i = 0; i < keyfiles_num; i++)
	{
		to = 0;
		from = 0;
		//keynum[i] 
		if (i == 0)
		{
			from = 0;
			to = keynum[i];
		}else{
			for (int j = 0; j < i + 1; j++)
			{
				to = to + keynum[j];
				if (j < i)
				{
					from = from + keynum[j];
				}
			}
		}
		outfile = key_files[i] + "matches.key";
		writeKey(outfile.c_str(), i, keynum[i], keypt, from, to);
		fprintf(f,"%s\n", outfile.c_str());
	}*/
	

    //delete [] keynum;
    delete [] matchkeynum;
    /*for(int i = 0; i < keyfiles_num; i++){
cout << i << "  \n";
	try{
	delete [] matchIdx[i];
	}
    }*/
    delete [] matchIdx;

	fclose(f);

    cout << "[DONE]" << endl;
    return 0;
}
