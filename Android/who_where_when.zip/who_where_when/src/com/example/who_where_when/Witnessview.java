package com.example.who_where_when;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Witnessview extends Activity {
	
	private String number, phurl, sturl1, sturl2,sturl3;
	ImageView imv,simv;
	TextView rank;
	int checkvote;
	String[] text1,sturls;
	private String SQL_order = "";
	private DBHelper dbhelper;
	private ProgressDialog pd;
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.witnessview);
		
		text1 = new String[3];
		text1[0]="�̬ۦ�";
		text1[1]="�ĤG�ۦ�";
		text1[2]="�ĤT�ۦ�";
		
				
		checkvote=1;
		Bundle bundle = getIntent().getExtras();
		number = bundle.getString("number");
		phurl = bundle.getString("phurl");
		sturl1 = bundle.getString("sturl1");
		sturl2 = bundle.getString("sturl2");
		sturl3 = bundle.getString("sturl3");
		
		sturls= new String[3];
		sturls[0]=sturl1;
		sturls[1]=sturl2;
		sturls[2]=sturl3;
		
		Button btnyes = (Button) findViewById(R.id.btnyes);
		btnyes.setOnClickListener(listener1);
		Button btnno = (Button) findViewById(R.id.btnno);
		btnno.setOnClickListener(listener2);
		
		rank=(TextView) findViewById(R.id.textView1);
		rank.setText(text1[0]);
		imv=(ImageView) findViewById(R.id.phimage);
		simv=(ImageView) findViewById(R.id.stimage);
		
		
	}
	
	private Button.OnClickListener listener1 = new Button.OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			
			openDataBase();//�}�Ҹ�Ʈw
			putDataToListView();
			dbhelper.onDestroy(); // close DataBase
			
			
			
			Toast.makeText(Witnessview.this, "�벼����"+checkvote+"�ۦ�",
					Toast.LENGTH_SHORT).show();
			
			Bundle password = new Bundle();
			Intent intent_publiclist ;
			
			SQL_order = "SELECT number,phurl,sturl1,sturl2,sturl3,status FROM Witness_Info";
			password.putString("SQL_order", SQL_order);
			intent_publiclist=new Intent(Witnessview.this,Witnessflist.class);
			intent_publiclist.putExtras(password);
			startActivity(intent_publiclist);
			
		}
		
	};
	
	private Button.OnClickListener listener2 = new Button.OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub 
			checkvote += 1;
			if (checkvote<4) {
				simv.setImageResource(R.drawable.nostimage); 
				rank.setText(text1[checkvote-1]);
				
				new AsyncTask<String, Void, Bitmap>()
	            {
	                @Override
	                protected Bitmap doInBackground(String... params)
	                {
	                    String url = params[0];
	                    return getBitmapFromURL(url);
	                }

	                @Override
	                protected void onPostExecute(Bitmap result)
	                {
	                	simv. setImageBitmap (result);
	                    super.onPostExecute(result);
	                }
	            }.execute(sturls[checkvote-1]);
			}
			else {
				openDataBase();//�}�Ҹ�Ʈw
				putDataToListView();
				dbhelper.onDestroy(); // close DataBase
				
				Toast.makeText(Witnessview.this, "�L�ۦ�",
						Toast.LENGTH_SHORT).show();
				
				Bundle password = new Bundle();
				Intent intent_publiclist ;
				
				SQL_order = "SELECT number,phurl,sturl1,sturl2,sturl3,status FROM Witness_Info";
				password.putString("SQL_order", SQL_order);
				intent_publiclist=new Intent(Witnessview.this,Witnessflist.class);
				intent_publiclist.putExtras(password);
				startActivity(intent_publiclist);
			}
			
		}
		
	};
	
	protected void putDataToListView()
	{
		
		pd = ProgressDialog.show(Witnessview.this, "���ݤ�", "��ƤW�Ǥ��еy��...");//���Dialog
		dataspendTime();//do context data function
	}
	
	private void openDataBase()
	{
		  dbhelper = new DBHelper(this);
		  try {
		   dbhelper.createDataBase();
		  } catch (IOException e) {
		   // TODO Auto-generated catch block
		   e.printStackTrace();
		  }		
	}
	
	private void dataspendTime() {
		new Thread(new Runnable() {//Thread �N�����æb�I�� doing background�A�`�NThread �̤��঳Layout �ƪ��]�m
			@Override
			public void run() {
				ContentValues values = new ContentValues();
				values.put("status", "�w�{��");
				SQLiteDatabase db = dbhelper.getWritableDatabase();
				db.update("Witness_Info", values, "number == "+number, null);
			}
		}).start();
	}
	
	@Override
	protected void onStart() {
			super.onStart();
			
			new AsyncTask<String, Void, Bitmap>()
            {
                @Override
                protected Bitmap doInBackground(String... params)
                {
                    String url = params[0];
                    return getBitmapFromURL(url);
                }

                @Override
                protected void onPostExecute(Bitmap result)
                {
                	imv. setImageBitmap (result);
                    super.onPostExecute(result);
                }
            }.execute(phurl);
            
            new AsyncTask<String, Void, Bitmap>()
            {
                @Override
                protected Bitmap doInBackground(String... params)
                {
                    String url = params[0];
                    return getBitmapFromURL(url);
                }

                @Override
                protected void onPostExecute(Bitmap result)
                {
                	simv. setImageBitmap (result);
                    super.onPostExecute(result);
                }
            }.execute(sturls[checkvote-1]);

	}
	
	private static Bitmap getBitmapFromURL(String imageUrl)
    {
        try
        {
            URL url = new URL(imageUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap bitmap = BitmapFactory.decodeStream(input);
            return bitmap;
        }
        catch (IOException e)
        {
            e.printStackTrace();
            return null;
        }
    }

}
