package com.example.who_where_when;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.hardware.Camera;
import android.hardware.Camera.CameraInfo;
import android.hardware.Camera.PictureCallback;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.ExifInterface;
import android.os.Bundle;
import android.os.Environment;
import android.text.format.Time;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Date;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TimeZone;

public class Photograph_page extends Activity implements SurfaceHolder.Callback,Camera.AutoFocusCallback  {

	private Intent intent = new Intent();
	int facing;
	private SurfaceView mSurfaceView;
    private SurfaceHolder mSurfaceHolder;
    private Camera camera;
    Display display;
    RelativeLayout ll;
    Button takepicture;
    TextView tv;
    MySensorListener sensorlistener;
    SensorManager smgr;
	Sensor sensor;
	
	private  LocationManager lmgr;
	Double longitude=0.0 ;	//經度
	Double latitude =0.0;	//緯度
	String slongitude="";
	String slatitude="";
	
	private DBHelper dbhelper;
	static String SQL_order="SELECT pid FROM Proof_Info";
	private Cursor data,data1; //資料庫data
	private Cursor databaseuseid;
	private int rows_num; //data數
	private ProgressDialog pd;
	
	private String pid,phtime,lat,lon,phurl, sturl="無", status="辨識中", reason="無";
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                   WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.photograph_page);
        
        display = getWindowManager().getDefaultDisplay();
        Intent intent = getIntent();
		facing = intent.getIntExtra("FACING",
				CameraInfo.CAMERA_FACING_FRONT);
        
        mSurfaceView = (SurfaceView) this.findViewById(R.id.sv);
        mSurfaceHolder = mSurfaceView.getHolder();
        mSurfaceHolder.addCallback(this);
        
        smgr = (SensorManager)getSystemService(SENSOR_SERVICE);
		sensorlistener = new MySensorListener();
		sensor = smgr.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        
		
		lmgr = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
		LocationListener locationListener  = new LocationListener() {
		    public void onLocationChanged(Location location) {
		      // Called when a new location is found by the network location provider.
		     // makeUseOfNewLocation(location);
		    	longitude = location.getLongitude();	//取得經度
				latitude = location.getLatitude();	//取得緯度
		     
				String str="";
		        str+=String.format("緯度:%.5f 經度:%.5f", location.getLatitude(),location.getLongitude());
		        lat = String.format("%.5f",location.getLatitude());
		        lon = String.format("%.5f",location.getLongitude());	
				tv.setText(str);
		    }

		    public void onStatusChanged(String provider, int status, Bundle extras) {}

		    public void onProviderEnabled(String provider) {}

		    public void onProviderDisabled(String provider) {}
		  };
		  lmgr.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListener);
		  
        LayoutInflater inflater = LayoutInflater.from(this);
        ll = (RelativeLayout)inflater.inflate(
				R.layout.addviews, null);
        tv = (TextView)ll.findViewById(R.id.tv_camerastatus);
        takepicture = (Button)ll.findViewById(R.id.btn_tp);
        takepicture.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (camera != null) {
					camera.takePicture(null, null, jpeg);
				}
			}
		});
        
        LayoutParams lp = new LayoutParams(
				LayoutParams.MATCH_PARENT,
				LayoutParams.WRAP_CONTENT);
		addContentView(ll, lp);
    }
    
	@Override
	public void onAutoFocus(boolean success, Camera camera) {
		// TODO Auto-generated method stub
		
		
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		
		CameraInfo info = new CameraInfo();
		int ncamera = Camera.getNumberOfCameras();
		for (int i = 0; i < ncamera; i++) {
			Camera.getCameraInfo(i, info);
			if (info.facing == facing) {
				camera = Camera.open(i);
				break;
			}
			Log.v("TEST","1");
		}
		if (camera == null) camera = Camera.open();
		//camera = Camera.open();
		int degrees = 0;
		int rotation = display.getRotation();
		switch (rotation) {
		case Surface.ROTATION_0: degrees = 0; break;
		case Surface.ROTATION_90: degrees = 90; break;
		case Surface.ROTATION_180: degrees = 180; break;
		case Surface.ROTATION_270: degrees = 270; break;
		}
		Log.v("TEST","4");
		int result;
		if (info.facing == CameraInfo.CAMERA_FACING_FRONT) {
			result = (info.orientation + degrees) % 360;
			result = (360 - result) % 360;  // compensate the mirror
		} else {  // back-facing
			result = (info.orientation - degrees + 360) % 360;
		}
		Log.v("TEST","5");
		camera.setDisplayOrientation(result);
		
		
        try {
            camera.setPreviewDisplay(holder);
        } catch (IOException e) {
            camera.release();
            camera = null;
        }
        Log.d("MYLOG","SurfaceView is Creating!");
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
		// TODO Auto-generated method stub
		Log.d("MYLOG","SurfaceView is Change!");
        camera.startPreview();
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		Log.d("MYLOG","SurfaceView is Destroyed!");
        camera.release();
        camera = null;
        
		
	}
	
	PictureCallback jpeg = new PictureCallback() {
		@Override
		public void onPictureTaken(byte[] data, Camera camera) {
			Bitmap bm = BitmapFactory.decodeByteArray(data,
					0, data.length);
			FileOutputStream fos = null;
			//bm=rotationBitmap(bm);
			try {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");//获取当前时间，进一步转化为字符串
				Date dt=new Date(System.currentTimeMillis());
				String dts=sdf.format(dt);
				

				openDataBase();//開啟資料庫
				databaseuseid = dbhelper.getData("SELECT useid FROM Use_ID");
				databaseuseid.moveToFirst();
				
				data1 = dbhelper.getData(SQL_order);//use sql order selcet DataBase data
				rows_num =data1.getCount();//查詢資料筆數
				pid=String.valueOf(rows_num+1);
				
	            String fileName = databaseuseid.getString(0)+"_"+pid+".jpg";
				
				File sdroot =
						Environment.getExternalStorageDirectory();
				File dir = new File(sdroot + "/streetimage");
				//先檢查該目錄是否存在
				if (!dir.exists()){
				    //若不存在則建立它
				    dir.mkdir();
				}
				
				File file = new File(dir, fileName);
				fos = new FileOutputStream(file);
				
				
				BufferedOutputStream bos =
						new BufferedOutputStream(fos);
				bm.compress(Bitmap.CompressFormat.JPEG, 100, bos);
				bos.flush();
				bos.close();
				Log.v("TEST", "## file=" + file);
				phurl= file.toString();
				SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy:MM:dd:HH:mm:ss");
				sdf2.setTimeZone(TimeZone.getTimeZone("Asia/Taipei"));
				String dts2=sdf2.format(dt);
				phtime=dts2;
				SimpleDateFormat sdfd = new SimpleDateFormat("yyyy:MM:dd");
				SimpleDateFormat sdft = new SimpleDateFormat("HH:mm:ss");
				String dts2d=sdfd.format(dt);
				String dts2t=sdft.format(dt);
				
				ExifInterface exifInterface = new ExifInterface(file.getAbsolutePath());
				
				exifInterface.setAttribute(ExifInterface.TAG_DATETIME,dts2);
				exifInterface.setAttribute(ExifInterface.TAG_MAKE,databaseuseid.getString(0));
				exifInterface.setAttribute(ExifInterface.TAG_GPS_LATITUDE,decimalToDMS(latitude)); //緯度
				exifInterface.setAttribute(ExifInterface.TAG_GPS_LATITUDE_REF,latitude > 0 ? "N" : "S");
				exifInterface.setAttribute(ExifInterface.TAG_GPS_LONGITUDE,decimalToDMS(longitude)); //經度
				exifInterface.setAttribute(ExifInterface.TAG_GPS_LONGITUDE_REF,longitude > 0 ? "E" : "W");
				exifInterface.setAttribute(ExifInterface.TAG_GPS_TIMESTAMP,dts2t);
				exifInterface.setAttribute(ExifInterface.TAG_GPS_DATESTAMP,dts2d);
				exifInterface.saveAttributes();
				
				/*ExifInterface exifInterface1 = new ExifInterface(file.getAbsolutePath());
				String dateTime = exifInterface1.getAttribute(ExifInterface.TAG_DATETIME);
				String latitude1 = exifInterface1.getAttribute(ExifInterface.TAG_GPS_LATITUDE);
				String longitude1 = exifInterface1.getAttribute(ExifInterface.TAG_GPS_LONGITUDE);
				String latitudeRef = exifInterface1.getAttribute(ExifInterface.TAG_GPS_LATITUDE_REF);
				String longitudeRef = exifInterface1.getAttribute(ExifInterface.TAG_GPS_LONGITUDE_REF);
				String gpsTimeStamp = exifInterface1.getAttribute(ExifInterface.TAG_GPS_TIMESTAMP);
				String gpsDateStamp = exifInterface1.getAttribute(ExifInterface.TAG_GPS_DATESTAMP);*/

				//photoupload();
				
				putDataToListView();
				dbhelper.onDestroy(); // close DataBase
				
				Toast.makeText(Photograph_page.this, "儲存成功",
						Toast.LENGTH_SHORT).show();
				camera.startPreview();
	            
			}catch (Exception e) {
				Toast.makeText(Photograph_page.this, "儲存失敗",
						Toast.LENGTH_SHORT).show();
			}
		}
	};
	
	protected void putDataToListView()
	{
		photoupload();
	}
	
	private void openDataBase()
	{
		  dbhelper = new DBHelper(this);
		  try {
		   dbhelper.createDataBase();
		  } catch (IOException e) {
		   // TODO Auto-generated catch block
		   e.printStackTrace();
		  }		
	}
	
	private void dataspendTime() {
		new Thread(new Runnable() {//Thread 將找資料藏在背景 doing background，注意Thread 裡不能有Layout 排版設置
			@Override
			public void run() {
				data = dbhelper.getData(SQL_order);//use sql order selcet DataBase data
				rows_num =data.getCount();//查詢資料筆數
				pid=String.valueOf(rows_num+1);
				
				
				dbhelper.appdata(pid,
						phtime,
						lat,
        				lon,
        				phurl,
        				sturl,
        				status,
        				reason);
				
			}
		}).start();
	}
	private void photoupload() {
		pd = ProgressDialog.show(Photograph_page.this, "等待中", "資料上傳中請稍後...");//顯示Dialog
		 new Thread(new Runnable() {
             @Override
             public void run() {
                 FileUpload mFileUpload = new FileUpload();
                 mFileUpload.setOnFileUploadListener(new FileUpload.OnFileUploadListener() {
                     @Override
                     public void onFileUploadSuccess(final String msg) {
                         runOnUiThread(new Runnable() {
                             @Override
                             public void run() {
                            	 Toast.makeText(Photograph_page.this, msg,
                 						Toast.LENGTH_SHORT).show();
                            	 if(msg.equals("success")) {
                            		 dataspendTime();//do context data function

                       				intent=new Intent(Photograph_page.this,Select_page.class);
                       	            startActivity(intent);
                             	 }
                             }
                         });

                     }

                     @Override
                     public void onFileUploadFail(final String msg) {
                         runOnUiThread(new Runnable() {
                             @Override
                             public void run() {
                            	 dataspendTime();//do context data function
                            	 Toast.makeText(Photograph_page.this, msg,
                 						Toast.LENGTH_SHORT).show();
                            	 if(msg.equals("success")) {

                      				intent=new Intent(Photograph_page.this,Select_page.class);
                      	            startActivity(intent);
                            	 }
                             }
                         });
                     }
                 });
                 mFileUpload.doFileUpload(phurl);
             }
             
         }).start();
	}
	
	public Bitmap rotationBitmap(Bitmap picture) {
		
        Matrix matrix = new Matrix();
        matrix.postRotate(270);
        Bitmap scaledBitmap = Bitmap.createScaledBitmap(picture,picture.getWidth(),picture.getHeight(),true);
        Bitmap rotatedBitmap = Bitmap.createBitmap(scaledBitmap , 0, 0, scaledBitmap .getWidth(), scaledBitmap .getHeight(), matrix, true);        
        return rotatedBitmap;
    } 
	
	@Override
	protected void onResume() {
		super.onResume();
		if (sensor != null)
			smgr.registerListener(sensorlistener, sensor,
					SensorManager.SENSOR_DELAY_NORMAL);
		
		/*String best =this.lmgr.getBestProvider(new Criteria(), true);
		
		if (best !=null) {
			lmgr.requestLocationUpdates(best, 1000, 1, this);
		}
		else
			Toast.makeText(this, "請開啟定位服務", Toast.LENGTH_LONG).show();*/
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		if (sensor != null)
			smgr.unregisterListener(sensorlistener, sensor);
		//lmgr.removeUpdates(this);
	}
	
	class MySensorListener implements SensorEventListener {
		
		@Override
		public void onSensorChanged(SensorEvent event) {
			/*String values="";
			values=values+event.values[0]+";"+event.values[1]+";"+event.values[2];
			tv.setText(values);*/
			takepicture.setClickable(true);
			/*if (event.values[0] <2 && event.values[0]> -2 && event.values[1]>0) {
				tv.setText("相機是正的"+latitude+";"+longitude);
				takepicture.setClickable(true);
			} else {
				tv.setText("相機拿歪了喔");
				takepicture.setClickable(false);
			}*/
		}
		
		@Override
		public void onAccuracyChanged(Sensor sensor, int accuracy) {
		}
	}
	
	public String decimalToDMS(double  coord) {
		
		String output, degrees, minutes, seconds;
		
		int intPart = (int)coord;
		degrees = String.valueOf(intPart);
 
		double mod = coord % 1;
		coord = mod * 60;
		intPart = (int) coord;
		minutes = String.valueOf(intPart);
		

		mod = coord % 1;
		coord = mod * 60;
		seconds = String.valueOf(coord);
		
		output = degrees + "," + minutes + "," + seconds + "";
 
		return output;
	}

	/*@Override
	public void onLocationChanged(Location location) {
		// TODO Auto-generated method stub
		
		longitude = location.getLongitude();	//取得經度
		latitude = location.getLatitude();	//取得緯度
     
		String str="";
        str+=String.format("緯度:%.5f 經度:%.5f", location.getLatitude(),location.getLongitude());
		tv.setText(str);
		/*DecimalFormat mDecimalFormat = new DecimalFormat("#.######");
		slongitude = mDecimalFormat.format(longitude);
		slatitude = mDecimalFormat.format(latitude);
		
		longitude = Double.parseDouble(slongitude);
		latitude = Double.parseDouble(slatitude)
	};*/

	/*@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onProviderEnabled(String provider) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onProviderDisabled(String provider) {
		// TODO Auto-generated method stub
		
	}*/
	
}
