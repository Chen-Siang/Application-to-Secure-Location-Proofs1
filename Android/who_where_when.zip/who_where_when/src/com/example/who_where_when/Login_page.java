package com.example.who_where_when;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class Login_page extends Activity {

	private Intent intent = new Intent();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login_page);
		
		//螢幕觸碰
		RelativeLayout layout= (RelativeLayout)findViewById(R.id.relativeLayout1);
        layout.setOnTouchListener(new View.OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					Netjudgment();
				}
				return true;
			}

			private LocationManager getSystemService(String locationService) {
				// TODO Auto-generated method stub
				return null;
			}
        	
        });
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.login_page, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	//網路、GPS判斷
	private void Netjudgment() {
		ConnectivityManager conManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);//先取得此service
		NetworkInfo networInfo = conManager.getActiveNetworkInfo();       //在取得相關資訊
		if (networInfo == null || !networInfo.isAvailable()){ //判斷是否有網路
			new AlertDialog.Builder(Login_page.this).setTitle("網路判斷")
				.setIcon(R.drawable.ic_launcher)
				.setMessage("裝置未連接網路，請確認網路連線")
				.setPositiveButton("確定", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
					}
			}).show();
		}
		else {
			//GPS判斷
			LocationManager status = (LocationManager) (this.getSystemService(Context.LOCATION_SERVICE));
			if (status.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
				intent=new Intent(Login_page.this,Select_page.class);
                startActivity(intent);
				/*//利用Toast的靜態函式makeText來建立Toast物件
				Toast toast = Toast.makeText(Login_page.this, 
						"成功", Toast.LENGTH_LONG);
				//顯示Toast
				toast.show();*/
			} 
			else{
				new AlertDialog.Builder(Login_page.this).setTitle("GPS判斷")
					.setIcon(R.drawable.ic_launcher)
					.setMessage("定位未開啟，請開啟GPS")
					.setPositiveButton("確定", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
						}
				}).show();
			}
		}
	}
	//判断GPS是否可用
	private boolean isGpsAble(LocationManager lm) {
        return lm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER) ? true : false;
    }
	
	// 捕捉返回鍵
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if ((keyCode == KeyEvent.KEYCODE_BACK)) {
			// MainActivity.this.finish();
			ConfimExit();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
	private void ConfimExit() {
		// TODO Auto-generated method stub
		new AlertDialog.Builder(Login_page.this).setTitle("離開")
		.setIcon(R.drawable.ic_launcher)
		.setMessage("確定要關閉程式嗎?")
		.setPositiveButton("確定", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				moveTaskToBack(true);
				android.os.Process.killProcess(android.os.Process.myPid());
			}
		})
		.setNegativeButton("取消", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
			}
		})
		.show();
	}
}
