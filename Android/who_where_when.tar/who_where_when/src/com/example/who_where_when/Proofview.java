package com.example.who_where_when;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Proofview extends Activity {
	
	private String phurl, sturl, status, reason;
	ImageView imv,simv;
	TextView status_text;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.proofview);
		
		Bundle bundle = getIntent().getExtras();
		phurl = bundle.getString("phurl");
		sturl = bundle.getString("sturl");
		status = bundle.getString("status");
		reason = bundle.getString("reason");
		
		Button verify = (Button) findViewById(R.id.button1);
		verify.setOnClickListener(listener1);
		verify.setVisibility(View.GONE);
		status_text =(TextView)findViewById(R.id.statusview);
		imv=(ImageView) findViewById(R.id.phimage);
		simv=(ImageView) findViewById(R.id.stimage);
		simv.setVisibility(View.GONE);
		
		status_text.setText(status);
		
		if(status.equals("����"))
			status_text.setText(reason+status);
		
		if (status.equals("���\")) {
			verify.setVisibility(View.VISIBLE);
			simv.setVisibility(View.VISIBLE);
			status_text.setVisibility(View.GONE);
			//�إߤ@��AsyncTask������i��Ϥ�Ū���ʧ@�A�ña�J�Ϥ��s�����}���|
            
		}
		
		showimage();
	}
	
	private Button.OnClickListener listener1 = new Button.OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			status_text.setText("���Ҥ�");
			status_text.setVisibility(View.VISIBLE);
		}
		
	};
	
	void showimage() {
		int iw,ih,vw,vh;
		BitmapFactory.Options option=new BitmapFactory.Options();
		option.inJustDecodeBounds=true;
		BitmapFactory.decodeFile(phurl,option);
		iw = option.outWidth;
		ih = option.outHeight;
		vw = 130;
		vh = 180;
		int scaleFactory = Math.min(iw/vw, ih/vh);
		option.inJustDecodeBounds = false;
		option.inSampleSize = scaleFactory;
		
		Bitmap bmp = BitmapFactory.decodeFile(phurl,option);
		imv.setImageBitmap(bmp);
		
	}
	
	@Override
	protected void onStart() {
			super.onStart();
			new AsyncTask<String, Void, Bitmap>()
            {
                @Override
                protected Bitmap doInBackground(String... params)
                {
                	Log.v("db", "1");
                    String url = params[0];
                    return getBitmapFromURL(url);
                }

                @Override
                protected void onPostExecute(Bitmap result)
                {
                	Log.v("db", "2");
                	simv. setImageBitmap (result);
                    super.onPostExecute(result);
                }
            }.execute(sturl);

	}
	
	private static Bitmap getBitmapFromURL(String imageUrl)
    {
        try
        {
            URL url = new URL(imageUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap bitmap = BitmapFactory.decodeStream(input);
            return bitmap;
        }
        catch (IOException e)
        {
            e.printStackTrace();
            return null;
        }
    }
}
