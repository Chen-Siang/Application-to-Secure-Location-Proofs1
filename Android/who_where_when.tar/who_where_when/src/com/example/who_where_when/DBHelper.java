package com.example.who_where_when;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import com.example.who_where_when.Setting;

public class DBHelper extends SQLiteOpenHelper {

	private static String DB_NAME = "WhoWhenWhere.sqlite"; //DataBase name
	private static String Info_TABLE = "Proof_Info";
	private static final int VERSION = 1;//��Ʈw������1�אּ2  
	 
	 private SQLiteDatabase db; //���DB
	 private final Context context; 
	 private String DB_PATH; //DB���|
	 private DBHelper dbHelper; //�غc�l
	 
	 ///�غc�l
	 public DBHelper(Context context) {
	  super(context, DB_NAME, null, VERSION);//context,name,null,version
	  this.context = context;
	  DB_PATH = "/data/data/" + context.getPackageName() + "/" + "databases/"; //���|�s��
	  
	 }
	 ///�إ�DB,�P�_�O�_���\�ƻsDB
	 public void createDataBase() throws IOException {
		boolean dbExist = checkDataBase();
		if (!dbExist || Setting.sqlupdatecheck == 1) {  
			
			this.getReadableDatabase();
			   try {
			    copyDataBase();
			    Setting.sqlupdatecheck = 0;
			   } catch (IOException e) {
//				   Log.e("error","Error copying database");
			   }
			
		 }
		 else {
//			 Log.v("recreate", "OK,"+dbExist);rrr
		 }  
	 }

	 //�P�_���LDB �Ǧ^���ѼƬ� ���L��(True or False)
	 private boolean checkDataBase() {
		  File dbFile = new File(DB_PATH + DB_NAME);
		  return dbFile.exists();
		 }

	 //��Assets��DB ��J���
	 private void copyDataBase() throws IOException {

	  InputStream myInput = context.getAssets().open(DB_NAME);
	  String outFileName = DB_PATH + DB_NAME;
	  //Log.v("copy", "OK=");
	  OutputStream mOutput = new FileOutputStream(outFileName);
	  byte[] mBuffer = new byte[1024];
	  int mLength;
	  while ((mLength = myInput.read(mBuffer))>0)
	  {
	      mOutput.write(mBuffer, 0, mLength);
	  }
	  //Log.v("copy", "OK");
	  mOutput.flush();
	  mOutput.close();
	  myInput.close();
	 }

	 //��DataBase�̪���� �ǤJSLQ order String �Ǧ^ Cursor data(���w���)
	 public Cursor getData(String sql_order) { 
	  dbHelper=new DBHelper(context);
	  db=dbHelper.getWritableDatabase();
	  return  db.rawQuery(sql_order, null);
	 }
	//close DataBase
	 public  void onDestroy(){
		 if(db!=null ||dbHelper!=null)
		 {db.close();
		  dbHelper.close();}
		 super.close();
	 }
	 
	 public long appdata(String pid, String phtime, String API_lat, String API_lon, 
			 String API_phurl,String API_sturl, String status, String reason){	
		 SQLiteDatabase db = dbHelper.getWritableDatabase();
		 ContentValues values = new ContentValues();
		 
		 values.put("pid", pid);
		 values.put("phtime", phtime);
         values.put("lat", API_lat);
         values.put("lon", API_lon);
         values.put("phurl", API_phurl);
         values.put("sturl", API_sturl);
         values.put("status", status);
         values.put("reason", reason);
         
         return db.insert(Info_TABLE, null, values);
	 }
	 
	 @Override
	 public void onCreate(SQLiteDatabase arg0) {
	  // TODO Auto-generated method stub
	 }

	 @Override
	 public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
	  // TODO Auto-generated method stub
//		 Log.v("recreate", Integer.toString(oldVersion));
//		 Log.v("recreate", Integer.toString(newVersion));
		 
		 
		 //�p�G�O��s���� ,�s���Ʀr���ª��Ʀr���N��Setting.sqlupdatecheck=1;
		 if (newVersion > oldVersion) {
//			 Log.v("recreate", Integer.toString(oldVersion));
			 Setting.sqlupdatecheck=1; 

			   
		 }
	 }	 
}
