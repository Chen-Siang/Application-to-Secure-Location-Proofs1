package com.example.who_where_when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.database.sqlite.SQLiteDatabase;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

public class Prooflist extends Activity {

	private DBHelper dbhelper; //DataBase class,use Linking SQLite DataBase
	static String SQL_order="";
	private String Title="";
	private ProgressDialog pd;
	private Cursor data; //��Ʈwdata
	private int rows_num; //data��
	private ListView lv; //result ������
	private Cursor databasetime; // ��Ʈw��s�ɶ�
	public String systemDataBaseTime = new String();
	private ProgressDialog PD; // Ū����Dialog
	public String API_STREEIMG =new String();
	public String API_STATE =new String();
	public String API_RESULT =new String();
	int pidid;
	
    public String API_database_time = new String();
	
	ArrayList<HashMap<String, Object>> Item; //ListView Model
	ArrayList<String> puliinfList = new ArrayList<String>();  //���w�OString�����A
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.prooflist);
		
		Button button1=(Button) findViewById(R.id.button1);
		button1.setOnClickListener(listener1);
		
		lv = (ListView) findViewById(R.id.showlist);
		Bundle bundle = getIntent().getExtras();
		SQL_order=bundle.getString("SQL_order");//�W�@���ǰe�L�Ӫ�sql order
		
		openDataBase();//�}�Ҹ�Ʈw
		putDataToListView();//Use Thread and handler to show this context
		dbhelper.onDestroy(); // close DataBase
	}
	
	private Button.OnClickListener listener1 = new Button.OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			//Toast.makeText(Prooflist.this, "��Ƨ�s��",Toast.LENGTH_SHORT).show();
			openDataBase();
			databasetime = dbhelper.getData("SELECT newtime FROM Database_time");
			databasetime.moveToFirst();
			systemDataBaseTime = databasetime.getString(0);
			
			new DownloadWebpageTask().execute();
			dbhelper.onDestroy();
		}
		
	};
	
	private class DownloadWebpageTask extends AsyncTask<Void,Integer,String[]>{
  
		@Override
		//�I���u�@�B�z�n�����Ʊ�
		protected String[] doInBackground(Void... params) {
            try{
                return getWebData();
            }catch (IOException e){
                e.printStackTrace();
                return null;
            }				
		}
		//�I���u�@�B�z��"��"�ݧ@����
		protected void onPostExecute(String[] result){
            super.onPostExecute(result);
        }
		public String[] getWebData() throws IOException{	
			String urlParkingArea = "http://163.22.21.149/student1.json";
            
			JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
            		urlParkingArea,
                    new Response.Listener<JSONObject>(){	
            			
            			@Override
                        public void onResponse(JSONObject response){
            				try{	
            					JSONObject obj = new JSONObject(response.toString());
								Log.d("FF","�i�J onResponse");
								//�˴��O�_�������
								API_database_time = obj.getString("database_time");
								Log.v("FF", API_database_time);
								if(Comparisontime(API_database_time) == true){
									PD = ProgressDialog.show(Prooflist.this, "���b��o�s���", "��s���A�Э@�ߵ���...");// ���Dialog
									JSONArray obj2 = obj.getJSONArray("item");
		                            //�ϥΰj�骺�覡����C�����
									
									String db_status="SELECT status FROM Proof_Info";
	                            	Cursor database_status = dbhelper.getData(db_status);
	                            	database_status.moveToFirst();
	                            	String systemDataBase_statuse = database_status.getString(0);
	                            	
		                            for (int i = 0; i < obj2.length(); i++) {
		                            	systemDataBase_statuse = database_status.getString(0);
		                            	JSONObject temp = new JSONObject(obj2.getString(i));
		                            	Log.v("pd","i:"+ i);
		                            	Log.v("pd","systemDataBase_statuse:"+systemDataBase_statuse);
		                            	//if(systemDataBase_statuse.equals("���Ѥ�")) {
		                            		pidid=i+1;
		                            		API_STREEIMG =temp.getString("STREEIMG");
		                            		API_STATE =temp.getString("STATE");
		                            		API_RESULT =temp.getString("RESULT");
		                            		Log.v("pd","API_STREEIMG:"+ API_STREEIMG);
		                            		Log.v("pd","API_STATE:"+ API_STATE);
		                            		Log.v("pd","API_RESULT:"+ API_RESULT);
		                            		dataUpdate();
		                            		
		                            	//}
		                            	database_status.moveToNext(); 
		                            }
		                            Bundle password = new Bundle();
		                			Intent intent_publiclist ;
		                			
		                			SQL_order = "SELECT phtime,lat,lon,phurl,sturl,status,reason FROM Proof_Info";
		                			password.putString("SQL_order", SQL_order);
		                			
		                			
		                			intent_publiclist=new Intent(Prooflist.this,Prooflist.class);
		                			intent_publiclist.putExtras(password);
		                			startActivity(intent_publiclist);
								}else{
            			    }		
            			}catch (JSONException e){
            				e.printStackTrace();
            				}
            			}
            		}, new Response.ErrorListener(){	
            			@Override
			            public void onErrorResponse(VolleyError error) {
			                Log.e("FF", error.getMessage(), error);
						}
            		}
            	);
			
            Volley.newRequestQueue(Prooflist.this).add(jsonObjectRequest);
            return new String[0];
		}
	}
	
	private void dataUpdate() {
		new Thread(new Runnable() {//Thread �N�����æb�I�� doing background�A�`�NThread �̤��঳Layout �ƪ��]�m
			@Override
			public void run() {
        		ContentValues values = new ContentValues();
				values.put("sturl", API_STREEIMG);
				values.put("status", API_STATE);
				
				values.put("reason", API_RESULT);
				Log.v("pd","status :"+ API_STATE);
				SQLiteDatabase db = dbhelper.getWritableDatabase();
				db.update("Proof_Info", values, "pid == "+pidid, null);
			}
		}).start();
	}
	
	private boolean Comparisontime(String Webtime){
        String t1 = Webtime;
        Log.v("TTT",t1);
        String t2 = systemDataBaseTime;
        Log.v("TTT",t2);
        java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy:MM:dd:HH:mm:ss");
        java.util.Calendar c1 = java.util.Calendar.getInstance();
        java.util.Calendar c2 = java.util.Calendar.getInstance();
        try{
            c1.setTime(df.parse(t1));
            c2.setTime(df.parse(t2));
        }catch (java.text.ParseException e){
        	System.err.println("�榡�����T");
            Log.v("FirstStart","��O�����T ���˹�榡");

        }
        Log.v("TTT",c1+"");
        Log.v("TTT",c2+"");
        int result = c1.compareTo(c2);
        Log.v("TTT",result+"");
        if (result > 0){
        	Toast.makeText(Prooflist.this,"��o��s��T",Toast.LENGTH_SHORT).show();
        	updatedatabasetime(Webtime);
//          Log.v("TTT","��o��s��T");
            return true;
        }else{
        	Toast.makeText(Prooflist.this,"���ݭn��s",Toast.LENGTH_SHORT).show();
//            Log.v("TTT","���ݭn��s");
            return false;
        }
    }
	
	private void updatedatabasetime(String databasetime){	
		ContentValues values = new ContentValues();
		values.put("newtime", databasetime);
		SQLiteDatabase db = dbhelper.getWritableDatabase();
		db.update("Database_time", values, "tid == 1", null);
	}
	
	private void openDataBase()
	{
		  dbhelper = new DBHelper(this);
		  try {
		   dbhelper.createDataBase();
		  } catch (IOException e) {
		   // TODO Auto-generated catch block
		   e.printStackTrace();
		  }		
	}
	
	protected void putDataToListView()
	{
		
		pd = ProgressDialog.show(Prooflist.this, "���ݤ�", "��Ʒj�M���еy��...");//���Dialog
		dataspendTime();//do context data function
	}
	
	public boolean onKeyDown(int keyCode, KeyEvent event) {//������^��
        if ((keyCode == KeyEvent.KEYCODE_BACK)) {  
        	Prooflist.this.onDestroy();
        	Prooflist.this.finish();
        	Intent intent=new Intent(Prooflist.this,Select_page.class);
            startActivity(intent);
            return true;   
        }   
        return super.onKeyDown(keyCode, event);   
    }
	
	private void dataspendTime() {
		new Thread(new Runnable() {//Thread �N�����æb�I�� doing background�A�`�NThread �̤��঳Layout �ƪ��]�m
			@Override
			public void run() {
				data = dbhelper.getData(SQL_order);//use sql order selcet DataBase data
				ArrayList<String> SameStr=new ArrayList<String>();//����Ʈw�̭�����Ʀ��L����
				SameStr.add("n/a");//���[�J�@��
				Boolean same=false;//�w�]�ثe�S���ۦP�r�궵�� 
				Item = new ArrayList<HashMap<String, Object>>();// �ϥ�ArrayList�A�M��HashMap<String, Object>���O�A�]�˹Ϥ��P��r�ԭz�C
				String puliinf = new String();
				rows_num =data.getCount();//�d�߸�Ƶ���
				if(rows_num!=0) //�Y��Ƥ����Ū��ɭԡA�h�N��Ƨ@�B�z�[�JItem ArrayList��
				{
					data.moveToFirst(); //data���w���V��ƪ����Ĥ@����� 
					for(int i=0;i<rows_num;i++)//����ƪ����
					{ 
						same=false;//�j��C�������ɭԳ��Nsame�w�]�S���ۦP�r�궵�� 
						//------------------�B�z��ƭ���----------------------------
						for(int j=0;j<SameStr.size();j++)//�Y��즳���ƪ���ơA�j��۰ʸ��X
						{ 
							if((SameStr.get(j).compareTo(data.getString(0)))==0){
								same=true; 
								break;
							}
						}
						if(same){
							data.moveToNext(); 
							continue;
						}//�����Ƹ�ƮɡA���L�H�U�{���X�A����U�@�Ӥ�ơA�~�򰵰j�鶵��
						HashMap<String, Object> map = new HashMap<String, Object>();
						
					    puliinf =data.getString(0)+","+ data.getString(1)+"  "+ data.getString(2)+","+ data.getString(3)+","+ data.getString(4)+","+ data.getString(5)+","+ data.getString(6);
				        puliinfList.add(puliinf);
					
				        SameStr.add(data.getString(0));
				        data.moveToNext();
					}
				 	for(int i=0;i<puliinfList.size();i++)
				 	{
				 		HashMap<String, Object> map = new HashMap<String, Object>();
				 		String[] AfterSplit = puliinfList.get(i).split(",");
					 
				        map.put("ItemTime", AfterSplit[0]); //�j�w�ɶ�
				        map.put("ItemGps", AfterSplit[1]);//�j�w �y��
				        map.put("ItemPhurl", AfterSplit[2]);//�j�wPhurl
				        map.put("ItemSturl", AfterSplit[3]);//�j�wSturl
				        map.put("ItemStatus", AfterSplit[4]);//�j�w���A
				        map.put("ItemReason", AfterSplit[5]);//�j�w��]
				        Item.add(map);
				 	}
				}
				handler.sendEmptyMessage(0);//�YThread �����ɡA��hold�h����ƳB�z
			}
		}).start();
	}
	
	
	Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			//============================================
			//ListView �����f �Hlv_BtnAdapter.class���O����f(�@��ListView���h���󪺮ĪG) �ؿ��b/scr/com/example/newbutterfly/lv_BtnAdapter.java
			//���f����[Activity , ArrayList<HashMap<String, Object>> ,String[] , int []];
			  lv_BtnAdapter Btnadapter = new lv_BtnAdapter(
					  Prooflist.this,
			  Item,
			         R.layout.adapter_button,
			         new String[] {"ItemTime","ItemGps","ItemPhurl","ItemSturl","ItemStatus","ItemReason"},//�����r����
			         new int[] {R.id.ItemTime,R.id.ItemGps,R.id.ItemPhurl,R.id.ItemSturl,R.id.ItemStatus,R.id.ItemReason}//����layout����id
			 );
			  lv.setAdapter(Btnadapter);
			  //==========================================
			    data.close();//�N��ƪ�����
			    dbhelper.onDestroy();//�N��Ʈw����
				
			  //ListView Item OnClickListener ,Click after from Result.this jamp ButterflyIllustrated.class
			  //�L�{���|��Butterfly name ��  ButterflyIllustrated Activity
			    
			    lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
		            @Override
					public void onItemClick(AdapterView<?> arg0, View view, int position,long id) {
		            	
		            	
		            	
		            	final TextView pphurl=(TextView) view.findViewById(R.id.ItemPhurl);
		            	final TextView ssturl=(TextView) view.findViewById(R.id.ItemSturl);
		            	final TextView sstatus=(TextView) view.findViewById(R.id.ItemStatus);
		            	final TextView rreason=(TextView) view.findViewById(R.id.ItemReason);
		            	
		            	final String phurl,sturl,status,reason;
     	
		            	
		            	phurl=pphurl.getText().toString();
		            	sturl=ssturl.getText().toString();
		            	status=sstatus.getText().toString();
		            	reason=rreason.getText().toString();
		            	
		            	
		            	Bundle password = new Bundle();
                        password.putString("phurl",phurl );
                        password.putString("sturl",sturl);
                        password.putString("status",status);
                        password.putString("reason",reason);
                       Intent newAct = new Intent();
                        newAct.setClass( Prooflist.this, Proofview.class );
                        
     	               newAct.putExtras(password);
     	               startActivity( newAct );
		            }
		            
		        });
			pd.dismiss();//ProgressDialog close
		}
	};
}
