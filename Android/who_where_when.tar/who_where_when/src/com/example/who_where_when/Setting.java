package com.example.who_where_when;

public class Setting {
	
	static int BunrateWidth1   ;
	static int 	BunrateHeight1;
	static int sqlupdatecheck;

}
