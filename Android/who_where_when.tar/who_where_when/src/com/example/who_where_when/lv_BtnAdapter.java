package com.example.who_where_when;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;

import android.R.integer;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.PixelFormat;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.location.LocationManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class lv_BtnAdapter extends BaseAdapter {
	
	private ArrayList<HashMap<String, Object>> mAppList;
	private LayoutInflater mInflater;
	private Context mContext;
	private String[] keyString;
	private int[] valueViewID;

	private ItemView itemView;
	 
	private class ItemView {
	   TextView ItemTime;
	   TextView ItemGps;
	   TextView ItemPhurl;
	   TextView ItemSturl;
	   TextView ItemStatus;
	   TextView ItemReason;
	}
	
	public lv_BtnAdapter(Context c, ArrayList<HashMap<String, Object>> appList, int resource, String[] from, int[] to) {
	   mAppList = appList;
	   mContext = c;
	   mInflater = (LayoutInflater)mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	   keyString = new String[from.length];
	   valueViewID = new int[to.length];
	   
	   System.arraycopy(from, 0, keyString, 0, from.length);
	   System.arraycopy(to, 0, valueViewID, 0, to.length);
	}
	 
	 @Override
	 public int getCount() {
	  // TODO Auto-generated method stub
	  //return 0;
	  return mAppList.size();
	 }

	 @Override
	 public Object getItem(int position) {
	  // TODO Auto-generated method stub
	  //return null;
	  return mAppList.get(position);
	 }

	 @Override
	 public long getItemId(int position) {
	  // TODO Auto-generated method stub
	  //return 0;
	  return position;
	 }

	 @Override
	 public View getView(int position, View convertView, ViewGroup parent) {
	  if (convertView != null) {
	   itemView = (ItemView) convertView.getTag();
	   } else {
	       convertView = mInflater.inflate(R.layout.adapter_button, null);
	       itemView = new ItemView();
	       itemView.ItemTime = (TextView)convertView.findViewById(valueViewID[0]);
	       itemView.ItemGps = (TextView)convertView.findViewById(valueViewID[1]);
	       itemView.ItemPhurl = (TextView)convertView.findViewById(valueViewID[2]);
	       itemView.ItemSturl = (TextView)convertView.findViewById(valueViewID[3]);
	       itemView.ItemStatus = (TextView)convertView.findViewById(valueViewID[4]);
	       itemView.ItemReason = (TextView)convertView.findViewById(valueViewID[5]);
	      
	       convertView.setTag(itemView);
	   }
	  if (position % 2 == 0) {
          convertView.setBackgroundResource(R.drawable.artists_list_backgroundcolor);
      } else {
    	  convertView.setBackgroundResource(R.drawable.artists_list_background_alternate);
      }
	   HashMap<String, Object> appInfo = mAppList.get(position);
	   if (appInfo != null) {
	  
	       
	       String ptime = (String) appInfo.get(keyString[0]);
	       String pgps = (String) appInfo.get(keyString[1]);
	       String phurl = (String) appInfo.get(keyString[2]);
	       String sturl = (String) appInfo.get(keyString[3]);
	       String status = (String) appInfo.get(keyString[4]);
	       String reason = (String) appInfo.get(keyString[5]);
	      
	       
	 
	       String test="";
	       
	       itemView.ItemTime.setText(ptime);
	       itemView.ItemGps.setText(pgps);
	       itemView.ItemPhurl.setText(phurl);
	       itemView.ItemSturl.setText(sturl);
	       itemView.ItemStatus.setText(status);
	       itemView.ItemReason.setText(reason);
	       
	       
	  }

	   return convertView;
	 }
	 
	 static Bitmap zoomDrawable(Drawable drawable, int w, int h)
	 {
	           int width = drawable.getIntrinsicWidth();
	           int height= drawable.getIntrinsicHeight();
//	           Log.v("TGA",width+":s:"+height);
	           Bitmap oldbmp = drawableToBitmap(drawable); 
	           Matrix matrix = new Matrix(); 
	           float scaleWidth = ((float)w / width); 
	           float scaleHeight = ((float)h / height);
//	           Log.v("TGA",scaleWidth+":c:"+scaleHeight);
	           matrix.postScale(scaleWidth, scaleHeight); 
	           Bitmap newbmp = Bitmap.createBitmap(oldbmp, 0, 0, width, height, matrix, true); 
	           return newbmp;  
	 }
	 
	 static Bitmap drawableToBitmap(Drawable drawable)
	 {
	           int width = drawable.getIntrinsicWidth();
	           int height = drawable.getIntrinsicHeight();
	         Bitmap.Config config = drawable.getOpacity() != PixelFormat.OPAQUE ? Bitmap.Config.ARGB_8888:Bitmap.Config.RGB_565;  
	           Bitmap bitmap = Bitmap.createBitmap(width, height, config);
	           Canvas canvas = new Canvas(bitmap); 
	           drawable.setBounds(0, 0, width, height);
	           drawable.draw(canvas);
	           return bitmap;
	 }
	 
	 //Buttin閫貊
	 class ItemButton_Click implements OnClickListener {
	   private int position;

	   ItemButton_Click(int pos) {
	       position = pos;
	   }

	   @Override
	   public void onClick(View v) {
	       int vid=v.getId();
	   }
	}
	}

