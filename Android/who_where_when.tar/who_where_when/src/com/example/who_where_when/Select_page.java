package com.example.who_where_when;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Select_page extends Activity {
	
	private Intent intent = new Intent();
	File tmpFile ;
	
	
	private String SQL_order = "";
	private DBHelper dbhelper; // DataBase class,use Linking SQLite DataBase
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.select_page);
		
		Button button1=(Button) findViewById(R.id.button1);
		button1.setOnClickListener(listener1);
		
		Button button2=(Button) findViewById(R.id.button2);
		button2.setOnClickListener(listener2);
		
		Button button3=(Button) findViewById(R.id.button3);
		button3.setOnClickListener(listener3);
		
		Button button5=(Button) findViewById(R.id.button5);
		button5.setOnClickListener(listener5);
		button5.setVisibility(View.GONE);
	}
	
	private Button.OnClickListener listener1 = new Button.OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			intent=new Intent(Select_page.this,Photograph_page.class);
            startActivity(intent);
			
		}
		
	};
	
	private Button.OnClickListener listener2 = new Button.OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Bundle password = new Bundle();
			Intent intent_publiclist ;
			
			SQL_order = "SELECT phtime,lat,lon,phurl,sturl,status,reason FROM Proof_Info";
			password.putString("SQL_order", SQL_order);
			
			
			intent_publiclist=new Intent(Select_page.this,Prooflist.class);
			intent_publiclist.putExtras(password);
			startActivity(intent_publiclist);
			
		}
		
	};
	
	private Button.OnClickListener listener3 = new Button.OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Bundle password = new Bundle();
			Intent intent_publiclist ;
			
			SQL_order = "SELECT number,phurl,sturl1,sturl2,sturl3,status FROM Witness_Info";
			password.putString("SQL_order", SQL_order);
			
			
			intent_publiclist=new Intent(Select_page.this,Witnessflist.class);
			intent_publiclist.putExtras(password);
			startActivity(intent_publiclist);
			
		}
		
	};
	
	private Button.OnClickListener listener5 = new Button.OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			/*intent=new Intent();
            intent.setAction("android.media.action.STILL_IMAGE_CAMERA");*/
			/*intent=new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(intent,100); */
			
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");//获取当前时间，进一步转化为字符串
			Date dt=new Date(System.currentTimeMillis());
			String dts=sdf.format(dt);
            String fileName = dts+".jpg";
			File sdroot =
					Environment.getExternalStorageDirectory();
			File dir = new File(sdroot + "/streetimage");
			//先檢查該目錄是否存在
			if (!dir.exists()){
			    //若不存在則建立它
			    dir.mkdir();
			}
			
			tmpFile = new File(dir, fileName);
			Uri uriMyImage = Uri.fromFile(tmpFile);
			intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
			intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, uriMyImage);
			startActivityForResult(intent, 0);
			
		}
		
	};
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
	     super.onActivityResult(requestCode, resultCode, data);
	     
	     if (resultCode == RESULT_OK) {
	    	 /*Bitmap bitmap = BitmapFactory.decodeFile(tmpFile.toString());
	          FileOutputStream fos = null;
	          try {
				fos = new FileOutputStream(tmpFile);
				BufferedOutputStream bos =
						new BufferedOutputStream(fos);
				bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bos);
				bos.flush();
				bos.close();
				
	          Toast.makeText(Select_page.this, "儲存成功",
						Toast.LENGTH_SHORT).show();
				
			}catch (Exception e) {
				Toast.makeText(Select_page.this, "儲存失敗",
						Toast.LENGTH_SHORT).show();
			}*/
	     }
	}
	/*protected void onActivityResult (int reqCode,int resCode,Intent data) {
		super.onActivityResult(reqCode, resCode, data);
		
		if (reqCode ==Activity.RESULT_OK && resCode==100) {
			Toast.makeText(this, "有拍攝到照片", Toast.LENGTH_LONG).show();
		}
		else {
			Toast.makeText(this, "沒有拍攝到照片", Toast.LENGTH_LONG).show();
		}
			
	}*/
	
	// 捕捉返回鍵
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if ((keyCode == KeyEvent.KEYCODE_BACK)) {
			// MainActivity.this.finish();
			ConfimExit();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
	private void ConfimExit() {
		// TODO Auto-generated method stub
		new AlertDialog.Builder(Select_page.this).setTitle("離開")
		.setIcon(R.drawable.ic_launcher)
		.setMessage("確定要關閉程式嗎?")
		.setPositiveButton("確定", new DialogInterface.OnClickListener() {
		@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				moveTaskToBack(true);
				android.os.Process.killProcess(android.os.Process.myPid());
			}
		})
		.setNegativeButton("取消", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
			}
		})
		.show();
	}

}
