package com.example.who_where_when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class Witnessflist extends Activity {

	private DBHelper dbhelper; //DataBase class,use Linking SQLite DataBase
	static String SQL_order="",number;
	private String Title="";
	private ProgressDialog pd;
	private Cursor data; //��Ʈwdata
	private Cursor w_integral;
	private int rows_num; //data��
	private ListView lv; //result ������
	TextView txtintegral;
	 
	ArrayList<HashMap<String, Object>> Item; //ListView Model
	ArrayList<String> puliinfList = new ArrayList<String>();  //���w�OString�����A
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.witnessflist);
		
		txtintegral=(TextView) findViewById(R.id.txtintegral);
		
		Button button1=(Button) findViewById(R.id.button1);
		button1.setOnClickListener(listener1);
		
		lv = (ListView) findViewById(R.id.showlist1);
		Bundle bundle = getIntent().getExtras();
		SQL_order=bundle.getString("SQL_order");//�W�@���ǰe�L�Ӫ�sql order
		
		openDataBase();//�}�Ҹ�Ʈw
		putDataToListView();//Use Thread and handler to show this context
		dbhelper.onDestroy(); // close DataBase
		
	}
	
	private Button.OnClickListener listener1 = new Button.OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Toast.makeText(Witnessflist.this, "��Ƨ�s��",
					Toast.LENGTH_SHORT).show();
			
		}
		
	};
	
	public boolean onKeyDown(int keyCode, KeyEvent event) {//������^��
        if ((keyCode == KeyEvent.KEYCODE_BACK)) {  
        	Witnessflist.this.onDestroy();
        	Witnessflist.this.finish();
        	Intent intent=new Intent(Witnessflist.this,Select_page.class);
            startActivity(intent);
            return true;   
        }   
        return super.onKeyDown(keyCode, event);   
    }
	
	private void openDataBase()
	{
		  dbhelper = new DBHelper(this);
		  try {
		   dbhelper.createDataBase();
		  } catch (IOException e) {
		   // TODO Auto-generated catch block
		   e.printStackTrace();
		  }		
	}
	
	protected void putDataToListView()
	{
		pd = ProgressDialog.show(Witnessflist.this, "���ݤ�", "��Ʒj�M���еy��...");//���Dialog
		dataspendTime();//do context data function
	}
	
	private void dataspendTime() {
		new Thread(new Runnable() {//Thread �N�����æb�I�� doing background�A�`�NThread �̤��঳Layout �ƪ��]�m
			@Override
			public void run() {
				w_integral = dbhelper.getData("SELECT earn_points FROM Integral_Info");
				w_integral.moveToFirst();
				int earn_points= w_integral.getInt(0);
				txtintegral.setText("�n��: "+earn_points);
				
				data = dbhelper.getData(SQL_order);//use sql order selcet DataBase data
				ArrayList<String> SameStr=new ArrayList<String>();//����Ʈw�̭�����Ʀ��L����
				SameStr.add("n/a");//���[�J�@��
				Boolean same=false;//�w�]�ثe�S���ۦP�r�궵�� 
				Item = new ArrayList<HashMap<String, Object>>();// �ϥ�ArrayList�A�M��HashMap<String, Object>���O�A�]�˹Ϥ��P��r�ԭz�C
				String puliinf = new String();
				rows_num =data.getCount();//�d�߸�Ƶ���
				if(rows_num!=0) //�Y��Ƥ����Ū��ɭԡA�h�N��Ƨ@�B�z�[�JItem ArrayList��
				{
					data.moveToFirst(); //data���w���V��ƪ����Ĥ@����� 
					for(int i=0;i<rows_num;i++)//����ƪ����
					{ 
						same=false;//�j��C�������ɭԳ��Nsame�w�]�S���ۦP�r�궵�� 
						//------------------�B�z��ƭ���----------------------------
						for(int j=0;j<SameStr.size();j++)//�Y��즳���ƪ���ơA�j��۰ʸ��X
						{ 
							if((SameStr.get(j).compareTo(data.getString(0)))==0){
								same=true; 
								break;
							}
						}
						if(same){
							data.moveToNext(); 
							continue;
						}//�����Ƹ�ƮɡA���L�H�U�{���X�A����U�@�Ӥ�ơA�~�򰵰j�鶵��
						HashMap<String, Object> map = new HashMap<String, Object>();
						
					    puliinf =data.getString(0)+","+ data.getString(1)+","+ data.getString(2)+","+ data.getString(3)+","+ data.getString(4)+","+ data.getString(5);
				        puliinfList.add(puliinf);
					
				        SameStr.add(data.getString(0));
				        data.moveToNext();
					}
				 	for(int i=0;i<puliinfList.size();i++)
				 	{
				 		HashMap<String, Object> map = new HashMap<String, Object>();
				 		String[] AfterSplit = puliinfList.get(i).split(",");
				 		
				        map.put("ItemNumber", AfterSplit[0]);
				        map.put("ItemwPhurl", AfterSplit[1]);
				        map.put("ItemSturl1", AfterSplit[2]);
				        map.put("ItemSturl2", AfterSplit[3]);
				        map.put("ItemSturl3", AfterSplit[4]);
				        map.put("ItemwStatus", AfterSplit[5]);
				        Item.add(map);
				 	}
				}
				handler.sendEmptyMessage(0);//�YThread �����ɡA��hold�h����ƳB�z
			}
		}).start();
	}
	
	
	Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			Log.v("wf","1");
			//============================================
			//ListView �����f �Hlv_BtnAdapter.class���O����f(�@��ListView���h���󪺮ĪG) �ؿ��b/scr/com/example/newbutterfly/lv_BtnAdapter.java
			//���f����[Activity , ArrayList<HashMap<String, Object>> ,String[] , int []];
			  lv_BtnAdapter2 Btnadapter = new lv_BtnAdapter2(
					  Witnessflist.this,
			  Item,
			         R.layout.adapter_button2,
			         new String[] {"ItemNumber","ItemwPhurl","ItemSturl1","ItemSturl2","ItemSturl3","ItemwStatus"},//�����r����
			         new int[] {R.id.ItemNumber,R.id.ItemwPhurl,R.id.ItemSturl1,R.id.ItemSturl2,R.id.ItemSturl3,R.id.ItemwStatus}//����layout����id
			 );
			  Log.v("wf","2");
			  lv.setAdapter(Btnadapter);
			  //==========================================
			  Log.v("wf","3");
			    data.close();//�N��ƪ�����
			    dbhelper.onDestroy();//�N��Ʈw����
				
			  //ListView Item OnClickListener ,Click after from Result.this jamp ButterflyIllustrated.class
			  //�L�{���|��Butterfly name ��  ButterflyIllustrated Activity
			    
			    lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
		            @Override
					public void onItemClick(AdapterView<?> arg0, View view, int position,long id) {
		            	
		            	//Intent intent=new Intent(Witnessflist.this,Witnessview.class);
			            //startActivity(intent);
		            	
		            	final TextView nnumber=(TextView) view.findViewById(R.id.ItemNumber);
		            	final TextView pphurl=(TextView) view.findViewById(R.id.ItemwPhurl);
		            	final TextView ssturl1=(TextView) view.findViewById(R.id.ItemSturl1);
		            	final TextView ssturl2=(TextView) view.findViewById(R.id.ItemSturl2);
		            	final TextView ssturl3=(TextView) view.findViewById(R.id.ItemSturl3);
		            	final TextView sstatus=(TextView) view.findViewById(R.id.ItemwStatus);
		            	
		            	final String phurl,sturl1,sturl2,sturl3,number,status;
     	
		            	
		            	number=nnumber.getText().toString();
		            	phurl=pphurl.getText().toString();
		            	sturl1=ssturl1.getText().toString();
		            	sturl2=ssturl2.getText().toString();
		            	sturl3=ssturl3.getText().toString();
		            	status=sstatus.getText().toString();
		            	
		            	
		            	Bundle password = new Bundle();
		            	password.putString("number",number );
                        password.putString("phurl",phurl );
                        password.putString("sturl1",sturl1);
                        password.putString("sturl2",sturl2);
                        password.putString("sturl3",sturl3);
                        Log.v("wf","status"+status);
                        
                        if (status.equals("�ШD�{��")) {
                        	Intent newAct = new Intent();
                            newAct.setClass( Witnessflist.this,Witnessview.class );
                            newAct.putExtras(password);
              	           	startActivity( newAct );
                        }
		            }
		        });
			pd.dismiss();//ProgressDialog close
		}
	};
	
}
